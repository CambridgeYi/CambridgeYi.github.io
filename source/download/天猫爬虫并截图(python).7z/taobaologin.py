# -*- coding: utf-8 -*-
import mimetypes
import time
import urllib
import json

import requests
import xlrd
import xlwt

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pyquery import PyQuery as pq
from flask import jsonify, make_response
from io import BytesIO


# 定义一个淘宝登录类
from models.tm_input_excel_model import TMInputExcelModel
from models.tm_output_excel_model import TMOutputExcelModel


class TaoBaoLogin:

    # 对象初始化
    def __init__(self):
        url = 'https://login.taobao.com/member/login.jhtml'
        self.url = url

        options = webdriver.ChromeOptions()
        options.add_experimental_option(
            "prefs", {
                "profile.managed_default_content_settings.images": 2})  # 不加载图片,加快访问速度
        options.add_experimental_option('excludeSwitches',
                                        ['enable-automation'])  # 此步骤很重要，设置为开发者模式，防止被各大网站识别出来使用了Selenium

        # self.browser = webdriver.Chrome(executable_path=chromedriver_path, options=options)
        self.browser = webdriver.Chrome(
            executable_path=chromedriver_path)
        self.wait = WebDriverWait(self.browser, 10)  # 超时时长为10s

    # 登录淘宝
    def login(self):
        # 打开网页
        self.browser.get(self.url)

        # 等待 密码登录选项 出现
        password_login = self.wait.until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '.qrcode-login > .login-links > .forget-pwd')))
        password_login.click()

        # 等待 微博登录选项 出现
        weibo_login = self.wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, '.weibo-login')))
        weibo_login.click()

        # 等待 微博账号 出现
        weibo_user = self.wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, '.username > .W_input')))
        weibo_user.send_keys(weibo_username)

        # 等待 微博密码 出现
        weibo_pwd = self.wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, '.password > .W_input')))
        weibo_pwd.send_keys(weibo_password)

        # 等待 登录按钮 出现
        submit = self.wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, '.btn_tip > a > span')))
        submit.click()

        # 直到获取到淘宝会员昵称才能确定是登录成功
        # taobao_name =
        # self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR,
        #                                     '.site-nav-bd > ul.site-nav-bd-l > li#J_SiteNavLogin > div.site-nav-menu-hd > div.site-nav-user > a.site-nav-login-info-nick ')))
        # 输出淘宝昵称
        # print(taobao_name.text)
        print("登录成功")

    def Crawl(self, tmInputs=[]):
        tmOutputs = []
        headers = {'Content-Type': 'application/json'}

        print('爬取总数据:{0} \r\n'.format(len(tm_inputs)))
        for index, input in enumerate(tm_inputs):
            output = TMOutputExcelModel(
                sku=input.sku,
                supplier_url=input.supplier_url,
                sku_name=input.sku_name)
            print('开始爬取URL:{0} \r\n'.format(input.supplier_url))

            print('SKU:{0} \r\n'.format(output.sku))
            self.browser.get(input.supplier_url)
            try:
                self.wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#J_DetailMeta")))
            except TimeoutError:
                print("{0}爬取失败".format(input.sku))
                continue
            except Exception as err:
                print("{0}爬取失败".format(input.sku))
                continue

            html = self.browser.page_source

            # pq模块解析网页源代码
            doc = pq(html)

            status = doc(".sold-out-tit").text()
            if status == "此商品已下架":
                output.tm_price = '已下架'
            else:
                prices = doc(".tm-price").text().split(' ')

                output.tm_price = prices[0]
                if len(prices) > 1:
                    output.tm_cx_price = prices[1]
                output.tm_name = doc(".tb-detail-hd h1").text()
            print("价格：{0} \r\n".format(output.tm_price))
            print("促销价格：{0} \r\n".format(output.tm_cx_price))
            print("sku名称:{0} \r\n".format(output.tm_name))
            # 截图

            self.browser.get(input.supplier_url)
            self.browser.maximize_window()
            time.sleep(2)
            try:
                is_picture_url = self.browser.get_screenshot_as_file(
                    './pictures/{0}.png'.format(output.sku))
                output.local_is_shot = is_picture_url
                if output.local_is_shot:
                    output.local_screen_shot_url = "E:\\code\\my\\mypython\\pictures\\{0}.png".format(
                        output.sku)
            except BaseException as msg:
                print(msg)
            print("本地是否截图成功:{0}\r\n".format(output.local_is_shot))
            # 上传到oss
            ossPath = self.upload_img(
                '{0}.png'.format(output.sku),
                output.local_screen_shot_url)
            if ossPath != '':
                output.oss_is_shot = True
                output.oss_screen_shot_url = ossPath
            print("oss是否截图成功:{0}\r\n".format(output.oss_is_shot))
            print("oss截图地址:{0} \r\n".format(output.oss_screen_shot_url))

            tmOutputs.append(output)
        return tmOutputs

    def read_excel(self):
        book = xlrd.open_workbook("./excels/colipu-suppliers.xlsx")
        sh = book.sheet_by_name("TM")
        tm_inputs = []

        for i in range(sh.nrows):
            if i == 0:
                continue
            row = sh.row_values(i)
            # 放在外面会将对象覆盖掉
            tm_input_item = TMInputExcelModel()
            if row[0] != '':
                tm_input_item.sku = row[0]
                tm_input_item.supplier_url = row[1]
                tm_input_item.sku_name = row[2]
                tm_inputs.append(tm_input_item)
        return tm_inputs

    def write_excel(self, outputs=[]):

        wb = xlwt.Workbook()
        ws = wb.add_sheet('天猫')
        ws.write(0, 0, "colipu商品sku")
        ws.write(0, 1, "天猫sku地址")
        ws.write(0, 2, "colipu商品名称")
        ws.write(0, 3, "天猫价格")
        ws.write(0, 4, "天猫促销价格")
        ws.write(0, 5, "天猫sku名称")
        ws.write(0, 6, "本地是否截图成功")
        ws.write(0, 7, "本地天猫截图地址")
        ws.write(0, 8, "OSS是否截图成功")
        ws.write(0, 9, "OSS天猫截图地址")
        row = 1
        col = 0
        for index, item in enumerate(outputs):
            ws.write(row, col, item.sku)
            ws.write(row, col + 1, item.supplier_url)
            ws.write(row, col + 2, item.sku_name)
            ws.write(row, col + 3, item.tm_price)
            ws.write(row, col + 4, item.tm_cx_price)
            ws.write(row, col + 5, item.tm_name)
            ws.write(row, col + 6, item.local_is_shot)
            ws.write(row, col + 7, item.local_screen_shot_url)
            ws.write(row, col + 8, item.oss_is_shot)
            ws.write(row, col + 9, item.oss_screen_shot_url)
            row += 1
        wb.save("./excels/tm_output.xls")

    def upload_img(self, filename, filefullpath):
        ossUrl = ''
        with open(filefullpath, 'rb') as f_abs:
            body = {
                'image_face': (filename, f_abs, "png/jpg")
            }
            response = requests.post(
                "http://localhost:59056/api/Screenshot/upload?supplier=tm",
                files=body)
            if response.status_code == 200:
                jsonObj = dict(json.loads(response.text))
                for (k, v) in jsonObj.items():
                    ossUrl = v
                    break
        return ossUrl


# 使用教程：
# 1.下载chrome浏览器:https://www.google.com/chrome/
# 2.查看chrome浏览器的版本号，下载对应版本号的chromedriver驱动:http://chromedriver.storage.googleapis.com/index.html
# 3.填写chromedriver的绝对路径
# 4.执行命令pip install selenium
# 5.打开https://account.weibo.com/set/bindsns/bindtaobao并通过微博绑定淘宝账号密码

if __name__ == "__main__":
    chromedriver_path = "./webdriver/chromedriver.exe"  # 改成你的chromedriver的完整路径地址
    weibo_username = "18721735935"  # 改成你的微博账号
    weibo_password = "king19880725"  # 改成你的微博密码

    tb = TaoBaoLogin()
    # 读取excel
    tm_inputs = tb.read_excel()

    # 登录
    tb.login()

    # 爬取数据
    tm_outputs = tb.Crawl(tm_inputs)

    # 导出数据
    tb.write_excel(tm_outputs)
    print('爬取完成...')
