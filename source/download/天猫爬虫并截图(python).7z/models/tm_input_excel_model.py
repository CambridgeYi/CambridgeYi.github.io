class TMInputExcelModel:
    sku = ''
    supplier_url = ''
    sku_name = ''

    def __init__(self, sku='', supplier_url='', sku_name=''):
        self.sku = sku
        self.supplier_url = supplier_url
        self.sku_name = sku_name
