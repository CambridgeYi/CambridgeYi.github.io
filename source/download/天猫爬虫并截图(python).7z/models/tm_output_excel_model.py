from models.tm_input_excel_model import TMInputExcelModel


class TMOutputExcelModel(TMInputExcelModel):
    tm_price = ''
    tm_cx_price = ''
    tm_name = ''
    local_is_shot = False
    local_screen_shot_url = ''
    oss_is_shot = False
    oss_screen_shot_url = ''

    def __init__(self, sku='', supplier_url='', sku_name='',
                 tm_price='', tm_cx_price='', tm_name='', local_is_shot=False, local_screen_shot_url='', oss_is_shot=False, oss_screen_shot_url=''):
        TMInputExcelModel.__init__(self, sku, supplier_url, sku_name)
        self.tm_price = tm_price
        self.tm_cx_price = tm_cx_price
        self.tm_name = tm_name
        self.local_is_shot = local_is_shot
        self.local_screen_shot_url = local_screen_shot_url
        self.oss_is_shot = oss_is_shot
        self.oss_screen_shot_url = oss_screen_shot_url
